# Ammar Asad — 3D Observatory Portfolio (Full Package)

This package contains everything: the live portfolio website + the complete design documentation.

## What's inside

```
ammar-portfolio-website/
├── website/                # The Next.js 16 app — runnable, deployable
│   ├── src/                # All source code (components, data, lib)
│   ├── public/             # Static assets
│   ├── prisma/             # Prisma schema (unused by portfolio, kept for scaffold consistency)
│   ├── examples/           # Reference examples (from the Next.js scaffold)
│   ├── package.json        # Dependencies
│   ├── bun.lock            # Lockfile (use bun, npm, or pnpm)
│   ├── next.config.ts
│   ├── tsconfig.json
│   ├── tailwind.config.ts
│   ├── postcss.config.mjs
│   ├── components.json
│   ├── eslint.config.mjs
│   ├── .gitignore
│   ├── .env.example        # Copy to .env (no real secrets needed)
│   ├── README.md           # Setup + customization guide
│   └── LICENSE             # MIT
│
├── design-docs/            # The 14 design documents + Phase 1 GitHub table
│   ├── phase6_research_report.md        # Research: Bruno Simon, Codrops, Awwwards principles
│   ├── phase7_identity.md               # Space observatory brand bible
│   ├── phase8_storytelling.md           # 8 beats with full copy
│   ├── phase9_ux_design.md              # Navigation, scroll, mobile, accessibility
│   ├── phase10_3d_experience.md         # Scene hierarchy, cameras, shaders, particles
│   ├── phase11_blender_pipeline.md      # Asset pipeline (v1 uses primitives, v2 backlog)
│   ├── phase12_project_presentation.md  # Per-flagship presentation + deep dives
│   ├── phase13_visual_design_system.md  # CSS tokens, typography, components
│   ├── phase14_technical_architecture.md# Folder structure, code patterns
│   ├── phase15_performance.md           # Targets, budgets, mobile strategy
│   ├── phase16_roadmap.md               # 9 milestones, risk assessment
│   ├── github_repos_table.md            # Phase 1 — all 32 repos fetched
│   └── github_repos.json                # Phase 1 raw data cache
│
├── phase5-analysis/        # Deep per-repo + cross-cutting analysis (Phase 5)
│   ├── cross_cutting_synthesis.md       # Patterns, strengths, gaps across 7 approved repos
│   ├── analysis_cache.json              # Raw analysis data
│   └── per_repo/                        # 7 individual repo analyses
│       ├── 01_exam_table.md
│       ├── 02_drama_ghar.md
│       ├── 03_hamara_rozgar.md
│       ├── 04_gcr_contacts.md
│       ├── 05_gcr_resources_fetch.md
│       ├── 06_internship_finder.md
│       └── 07_wayfinder.md
│
└── worklog.md              # Multi-agent work log (Phase 1 → final build)
```

## Quick start

1. Unzip this package.
2. `cd website/`
3. `bun install` (or `npm install` / `pnpm install`)
4. `bun run dev` (or `npm run dev` / `pnpm dev`)
5. Open http://localhost:3000

## Deploying

The portfolio is a static Next.js app — no backend, no database, no API keys. Deploy to Vercel (recommended), Netlify, or any static host.

```bash
cd website/
vercel   # Vercel CLI auto-deploys
```

## Why the design docs are included

Every visual + engineering decision in the portfolio has a documented rationale. If you want to change anything (a color, a beat's copy, a project's presentation), read the relevant design doc first — it tells you *why* that choice was made, which makes iteration faster.

- Want to change the palette? → `design-docs/phase7_identity.md` + `phase13_visual_design_system.md`
- Want to rewrite project copy? → `design-docs/phase12_project_presentation.md`
- Want to change the camera path? → `design-docs/phase10_3d_experience.md` + `website/src/components/three/scene-constants.ts`
- Want to add a new project? → `design-docs/phase12_project_presentation.md` + `website/src/data/projects.ts` + a new component in `website/src/components/three/projects/`

## Credits

- **Developer:** Ammar Asad (@ammarasad2005)
- **Design + build:** Custom for this portfolio
- **Inspiration:** Bruno Simon, Codrops, Awwwards winners
