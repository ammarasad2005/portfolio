# Ammar Asad — 3D Observatory Portfolio

A memorable, story-driven 3D developer portfolio built with Next.js 16, React Three Fiber, Three.js, GSAP, and Tailwind CSS 4.

The visitor arrives at a quiet observatory floating in deep navy space, scrolls to aim a telescope, and discovers 7 of Ammar's projects as celestial bodies — each with its own visual treatment and storytelling moment.

## Tech Stack

- **Framework:** Next.js 16 (App Router) + TypeScript
- **3D:** Three.js + React Three Fiber + Drei
- **Animation:** GSAP (scroll-linked camera) + Framer Motion (UI transitions)
- **Styling:** Tailwind CSS 4 with custom design tokens
- **State:** Zustand (scroll progress, current beat, sound toggle)
- **Fonts:** Fraunces (display serif) + Inter (body) + JetBrains Mono (technical) via `next/font`
- **Icons:** lucide-react

## Quick Start

```bash
# 1. Install dependencies
bun install
#   (or npm install / pnpm install)

# 2. Run the dev server
bun run dev
#   (or npm run dev / pnpm dev)

# 3. Open http://localhost:3000
```

The portfolio runs entirely on port 3000. No backend, no database, no API keys required.

## Project Structure

```
src/
├── app/
│   ├── layout.tsx          # Root layout with fonts + metadata
│   ├── page.tsx            # Main scroll container (14 beats: 8 chapters + 7 project sub-beats)
│   └── globals.css         # Design tokens + dark theme + reduced-motion fallback
│
├── components/
│   ├── three/              # All 3D scene components
│   │   ├── scene.tsx                    # Root <Canvas> with lights + ambient env
│   │   ├── scene-constants.ts           # Camera control points + Catmull-Rom path sampler
│   │   ├── camera-rig.tsx               # Scroll-linked camera with idle drift
│   │   ├── starfield.tsx                # 300 twinkling stars (custom shader)
│   │   ├── nebula-background.tsx        # Background gradient sphere (3-octave noise shader)
│   │   ├── project-bodies.tsx           # Wrapper that mounts all 7 project bodies
│   │   └── projects/                    # One component per project celestial body:
│   │       ├── exam-table-planet.tsx              # Planet + ring (Web pillar)
│   │       ├── drama-ghar-binary-planet.tsx       # Binary planets (teamwork)
│   │       ├── hamara-rozgar-nebula.tsx           # 5000-particle nebula + 4 agent pulses
│   │       ├── glucoguard-star.tsx                # 4-pulse star (4-model pipeline)
│   │       ├── internship-finder-satellite.tsx    # Blinking satellite (Building Now)
│   │       ├── gcr-fetch-comet.tsx                # Comet with particle trail
│   │       └── wayfinder-speck.tsx                # Distant dim speck
│   │
│   ├── dom/                # DOM overlay components (the text + UI on top of 3D)
│   │   ├── loading-screen.tsx         # "Calibrating Telescope" sequence
│   │   ├── hero-text.tsx              # Beat 1 hero
│   │   ├── intro-panel.tsx            # Beat 2 introduction
│   │   ├── exploration-cues.tsx       # Beat 3 how-to
│   │   ├── project-info-panel.tsx     # Beat 4 (data-driven, used 7 times)
│   │   ├── stack-map-overlay.tsx      # Beat 5 technical credibility
│   │   ├── personality-panel.tsx      # Beat 6 music + writing
│   │   ├── future-panel.tsx           # Beat 7 ambitions
│   │   ├── contact-panel.tsx          # Beat 8 dawn finale
│   │   ├── progress-indicator.tsx     # Right-edge orbit path with 8 dots
│   │   ├── sound-toggle.tsx           # Top-right toggle (localStorage)
│   │   └── custom-cursor.tsx          # Lagging cursor (desktop)
│   │
│   └── ui-observatory/     # Custom UI primitives (styled to match the observatory theme)
│       ├── glass-panel.tsx            # Glassmorphism surface
│       ├── stack-chip.tsx             # Tech stack pill
│       ├── pillar-badge.tsx           # Color-coded per pillar (web/ai/mobile)
│       ├── building-now-badge.tsx     # Pulsing badge for in-progress projects
│       └── cta-button.tsx             # Primary + ghost button variants
│
├── data/                   # All content is data-driven (change copy here, not in components)
│   ├── projects.ts        # 7 projects with titles, subtitles, stack, body, CTAs, deepDive type
│   ├── beats.ts           # 8 beat definitions (chapter titles + subtitles)
│   └── stack-map.ts       # 14 stack entries with repo counts
│
└── lib/
    ├── store.ts           # Zustand store (scrollProgress, currentBeat, soundEnabled)
    └── use-scroll.ts      # Scroll listener hook (RAF-throttled)
```

## The 8 Beats

The portfolio is structured as 8 chapters (called "beats") the visitor scrolls through:

1. **Arrival** — Observatory dome opens, hero text fades in.
2. **Introduction** — Who is the observer (Ammar).
3. **Exploration** — How to use the telescope (scroll, hover, click).
4. **Projects** — 7 sub-beats, one per project. Each project is a celestial body the telescope focuses on.
5. **Technical credibility** — Holographic stack map with 14 technologies sized by repo frequency.
6. **Personality** — Music + writing. "Now playing: Brian Eno — Apollo".
7. **Future ambitions** — Short / mid / long-term goals.
8. **Contact** — Dawn finale, contact links, wordmark materializes.

## Customization

### Change project content
Edit `src/data/projects.ts`. Each project has: `title`, `subtitle`, `pillar` (web/ai/mobile), `status` (complete/building/early), `badge`, `stackChips[]`, `body`, `engineeringNote`, `ctas[]`, `repoUrl`, optional `deepDive`.

### Change beat copy
Edit `src/data/beats.ts`.

### Change colors
Edit the CSS variables in `src/app/globals.css` under `:root`. Key tokens:
- `--bg-deep: #0A1530` (deep navy background)
- `--text-primary: #F5F0E1` (ivory)
- `--accent-sunset: #FF6B35` (sunset orange)
- `--pillar-web`, `--pillar-ai`, `--pillar-mobile` (per-pillar colors)

### Change 3D scene
- Camera path: `src/components/three/scene-constants.ts` (`CAMERA_CONTROL_POINTS` array)
- Project body positions: `src/data/projects.ts` (`projectPositions` map)
- Star count, nebula colors: `src/components/three/starfield.tsx`, `nebula-background.tsx`

## Accessibility

- `prefers-reduced-motion` triggers a static fallback (flat chapter cards, no 3D, no animations)
- 3D canvas is `aria-hidden="true"`; a complete semantic HTML duplicate of all content exists for screen readers
- All interactive elements are keyboard-navigable (Tab, Enter, Esc)
- Progress indicator dots are clickable for jump-navigation
- Color contrast meets WCAG AA (most text meets AAA)

## Performance

- Initial JS bundle: ~135KB gzipped
- 3D chunk: ~230KB gzipped (lazy-loaded after first paint)
- 60 FPS target on desktop, 30 FPS on mid-range mobile
- Pixel ratio capped at 2 (not 3) on retina displays
- Mobile halves star count and disables post-processing

## Deployment

The portfolio is a static Next.js app — no server-side data, no ISR/SSR needed. Recommended: Vercel.

```bash
# Option 1: Vercel CLI
npm i -g vercel
vercel

# Option 2: Connect GitHub repo on vercel.com — auto-deploys on push to main
```

No environment variables are required for the portfolio itself. The `.env.example` is only there for the optional Prisma setup (which the portfolio doesn't actually use).

## Design Documentation

The complete design rationale — 14 documents covering research, identity, storytelling, UX, 3D experience, Blender pipeline, project presentation, visual design system, technical architecture, performance engineering, and the development roadmap — is in the `../design-docs/` folder of this package.

## License

MIT. See `LICENSE` file (add one if you fork this).

## Credits

- **Developer:** Ammar Asad (@ammarasad2005)
- **Design system + 3D experience:** Custom-built for this portfolio
- **Inspiration:** Bruno Simon's portfolio, Codrops scroll-driven 3D world tutorials, Awwwards winners
