import type { Metadata } from "next";
import { Fraunces, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  variable: "--font-display",
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500", "600"],
  display: "swap",
});

const inter = Inter({
  variable: "--font-body",
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-mono",
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Ammar Asad — Curious Engineer, Quiet Observer",
  description:
    "Full-stack web · AI/ML · Mobile. Building agentic AI for Pakistan. A 3D observatory of projects.",
  keywords: [
    "Ammar Asad",
    "software engineer",
    "agentic AI",
    "Next.js",
    "TypeScript",
    "Pakistan",
    "portfolio",
  ],
  authors: [{ name: "Ammar Asad" }],
  openGraph: {
    title: "Ammar Asad — Curious Engineer, Quiet Observer",
    description:
      "Full-stack web · AI/ML · Mobile. Building agentic AI for Pakistan.",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Ammar Asad — Curious Engineer, Quiet Observer",
    description:
      "Full-stack web · AI/ML · Mobile. Building agentic AI for Pakistan.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`dark ${fraunces.variable} ${inter.variable} ${jetbrainsMono.variable}`} suppressHydrationWarning>
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
