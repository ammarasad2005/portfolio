'use client';

import { motion } from 'framer-motion';
import { GlassPanel } from '@/components/ui-observatory/glass-panel';

interface Ambition {
  horizon: 'Short-term' | 'Mid-term' | 'Long-term';
  copy: string;
  accent: string;
}

const ambitions: Ambition[] = [
  {
    horizon: 'Short-term',
    copy: 'Software engineering internship at a strong tech company. I want to learn how production systems scale.',
    accent: 'var(--accent-cyan)',
  },
  {
    horizon: 'Mid-term',
    copy: "Contribute to open-source agentic AI tooling. Build my hamara-rozgar and Internship-Finder into mature systems.",
    accent: 'var(--accent-amber)',
  },
  {
    horizon: 'Long-term',
    copy: "Build a company that brings agentic AI to Pakistan's informal economy at scale. Or join a lab doing this work.",
    accent: 'var(--accent-sunset)',
  },
];

/**
 * FuturePanel — Beat 7.
 * Per phase8_storytelling.md Beat 7.
 */
export function FuturePanel() {
  return (
    <div className="w-full px-4 md:px-12 max-w-4xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: false, amount: 0.3 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        <div className="mb-8 text-center">
          <div className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.04em] text-[var(--text-muted)] mb-3">
            <span className="h-px w-6 bg-[var(--border-strong)]" />
            Beat 7 · Where the Telescope Turns Next
          </div>
          <h2 className="font-display text-[40px] md:text-[64px] leading-[1.05] tracking-[-0.02em] text-[var(--text-primary)]">
            Where the telescope turns next.
          </h2>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          {ambitions.map((a, i) => (
            <motion.div
              key={a.horizon}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: false }}
              transition={{
                duration: 0.6,
                delay: 0.15 + i * 0.12,
                ease: [0.16, 1, 0.3, 1],
              }}
            >
              <GlassPanel className="p-6 h-full">
                <div className="flex items-center gap-2 mb-3">
                  <span
                    className="inline-block h-2 w-2 rounded-full"
                    style={{ background: a.accent, boxShadow: `0 0 10px ${a.accent}` }}
                    aria-hidden="true"
                  />
                  <span className="font-mono text-[11px] uppercase tracking-[0.04em] text-[var(--text-secondary)]">
                    {a.horizon}
                  </span>
                </div>
                <p className="font-body text-[15px] md:text-[16px] leading-[1.55] text-[var(--text-primary)]">
                  {a.copy}
                </p>
              </GlassPanel>
            </motion.div>
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: false }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-8 text-center font-mono text-[13px] text-[var(--text-muted)] italic"
        >
          Dream rooms: Google, OpenAI, Anthropic, Mozilla, CNCF, academic labs.
          I&apos;d rather build for real people than polish demos.
        </motion.p>
      </motion.div>
    </div>
  );
}
