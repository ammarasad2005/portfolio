'use client';

import { motion } from 'framer-motion';
import { GlassPanel } from '@/components/ui-observatory/glass-panel';

/**
 * PersonalityPanel — Beat 6.
 * Per phase8_storytelling.md Beat 6.
 *
 * Handwritten notebook + "Now playing" chip.
 */
export function PersonalityPanel() {
  return (
    <div className="w-full px-4 md:px-12 max-w-3xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: false, amount: 0.3 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        <div className="mb-6">
          <div className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.04em] text-[var(--text-muted)] mb-3">
            <span className="h-px w-6 bg-[var(--border-strong)]" />
            Beat 6 · The Observer Beyond Code
          </div>
        </div>

        <GlassPanel className="p-6 md:p-10">
          {/* Now playing chip */}
          <div className="inline-flex items-center gap-2.5 mb-8 px-3 py-1.5 rounded-full bg-[rgba(255,107,53,0.08)] border border-[rgba(255,107,53,0.2)]">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full rounded-full bg-[var(--accent-sunset)] opacity-75 animate-ping" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-[var(--accent-sunset)]" />
            </span>
            <span className="font-mono text-[11px] uppercase tracking-[0.04em] text-[var(--text-secondary)]">
              Now playing · Brian Eno — Apollo
            </span>
          </div>

          <h2 className="font-display text-[28px] md:text-[40px] leading-[1.1] tracking-[-0.02em] text-[var(--text-primary)] mb-6">
            When I&apos;m not building, I&apos;m listening — or writing.
          </h2>

          <div className="space-y-5">
            <p className="font-body text-[17px] md:text-[18px] leading-[1.6] text-[var(--text-secondary)]">
              Music shapes how I think about pacing. A good transition has a
              downbeat. A good portfolio has a rhythm.
            </p>

            <p className="font-body text-[17px] md:text-[18px] leading-[1.6] text-[var(--text-secondary)]">
              Writing shapes how I think about clarity. If I can&apos;t explain
              it in a paragraph, I don&apos;t understand it yet.
            </p>
          </div>

          {/* Handwritten notebook line — a small accent */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: false }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-8 pt-6 border-t border-[var(--border-subtle)]"
          >
            <p className="handwritten text-[22px] md:text-[26px] text-[var(--accent-amber)] leading-[1.4]">
              &ldquo;Slow down to speed up.&rdquo;
            </p>
            <p className="mt-2 font-mono text-[11px] uppercase tracking-[0.04em] text-[var(--text-muted)]">
              — notebook margin, sometime in 2026
            </p>
          </motion.div>
        </GlassPanel>
      </motion.div>
    </div>
  );
}
