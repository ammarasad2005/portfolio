// Project data for the observatory portfolio.
// All copy sourced from phase12_project_presentation.md.
// Engineering notes use Phase 5 analysis_cache.json numbers.

export type Pillar = 'web' | 'ai' | 'mobile';
export type ProjectStatus = 'complete' | 'building' | 'early';

export type DeepDiveKey =
  | 'exam-table-blueprint'
  | 'drama-ghar-rubric'
  | 'hamara-rozgar-pipeline'
  | 'glucoguard-pipeline'
  | 'internship-finder-workflow';

export interface ProjectCTA {
  label: string;
  href: string;
  variant?: 'primary' | 'ghost';
}

export interface Project {
  id: string;
  title: string;
  subtitle: string;
  pillar: Pillar;
  status: ProjectStatus;
  badge?: string;
  stackChips: string[];
  body: string;
  engineeringNote: string;
  ctas: ProjectCTA[];
  repoUrl: string;
  deepDive?: DeepDiveKey;
  /** Body type drives which 3D representation is used. */
  bodyType:
    | 'planet'
    | 'binary'
    | 'nebula'
    | 'star'
    | 'satellite'
    | 'comet'
    | 'speck';
}

export const projects: Project[] = [
  {
    id: 'exam-table',
    title: 'FAST Isb Utilities',
    subtitle: 'The unified campus companion for FAST NUCES Islamabad',
    pillar: 'web',
    status: 'complete',
    stackChips: [
      'Next.js 14',
      'React 18',
      'TypeScript',
      'Supabase',
      'Tailwind',
      'Framer Motion',
      'Playwright',
    ],
    body: 'No more digging through messy Google Sheets. No more searching emails for exam schedules. Everything in one place — built for my fellow FAST students.',
    engineeringNote:
      '172 files · 30,392 LoC · 100 commits · Playwright E2E · live demo on Vercel',
    ctas: [
      {
        label: 'Live Demo',
        href: 'https://fast-nuces.vercel.app/',
        variant: 'primary',
      },
      {
        label: 'Source',
        href: 'https://github.com/ammarasad2005/Exam-Table',
        variant: 'ghost',
      },
      { label: 'Case study', href: '#', variant: 'ghost' },
    ],
    repoUrl: 'https://github.com/ammarasad2005/Exam-Table',
    deepDive: 'exam-table-blueprint',
    bodyType: 'planet',
  },
  {
    id: 'drama-ghar',
    title: 'DramaGhar',
    subtitle: 'A full-stack Pakistani drama tracking & streaming platform',
    pillar: 'web',
    status: 'complete',
    stackChips: [
      'Next.js 15',
      'React 19',
      'TypeScript',
      'MongoDB Atlas',
      'Supabase',
      'Radix/shadcn',
      'Zod',
      'React Hook Form',
    ],
    body: 'Built with Hanzlah Ch for a Web Programming course. Streaming + tracking + RBAC + session management. The README includes a self-evaluation rubric — academic-grade documentation.',
    engineeringNote:
      '101 files · 6,773 LoC · 32 commits · 2 contributors · Next.js 15 + React 19 (latest at time of build)',
    ctas: [
      {
        label: 'Source',
        href: 'https://github.com/ammarasad2005/Drama-Ghar',
        variant: 'ghost',
      },
      { label: 'Case study', href: '#', variant: 'ghost' },
    ],
    repoUrl: 'https://github.com/ammarasad2005/Drama-Ghar',
    deepDive: 'drama-ghar-rubric',
    bodyType: 'binary',
  },
  {
    id: 'hamara-rozgar',
    title: 'Hamara-Rozgar (RozgarOrch)',
    subtitle: "Agentic AI marketplace orchestrator for Pakistan's informal economy",
    pillar: 'ai',
    status: 'building',
    badge: '🛠️ Building Now — actively iterating',
    stackChips: [
      'React 19',
      'Vite',
      'Firebase',
      'Capacitor (Android APK)',
      'Python scraper',
      'Multi-agent pipeline',
      'OSM',
      'Supabase',
      'Ollama',
      'Groq',
      'GitHub Models',
    ],
    body: "Built for the Google Antigravity Hackathon. Plumbers, electricians, tutors, AC technicians, beauticians, mechanics — find them through natural language in Urdu, Roman Urdu, or English. Proximity matching, travel-adjusted pricing, anomaly resolution.",
    engineeringNote:
      '100% Google-Cloud-evacuated — runs fully offline with open-source alternatives. Multi-agent cooperative pipeline: IntentAgent → DiscoveryAgent → PricingAgent → BookingAgent. Android APK shipped. 100 commits of active iteration.',
    ctas: [
      {
        label: 'Source',
        href: 'https://github.com/ammarasad2005/hamara-rozgar',
        variant: 'ghost',
      },
      { label: 'Architecture diagram', href: '#', variant: 'ghost' },
      {
        label: 'APK download',
        href: 'https://github.com/ammarasad2005/hamara-rozgar/raw/main/Hamara_Rozgar.apk',
        variant: 'primary',
      },
    ],
    repoUrl: 'https://github.com/ammarasad2005/hamara-rozgar',
    deepDive: 'hamara-rozgar-pipeline',
    bodyType: 'nebula',
  },
  {
    id: 'glucoguard-plus',
    title: 'GlucoGuard+ 🛡️',
    subtitle: 'Apne khaane ka guard banayein. Awaaz mein. Roman Urdu mein.',
    pillar: 'ai',
    status: 'complete',
    stackChips: [
      'Python',
      'Streamlit',
      'OpenAI gpt-4o-mini (vision + reasoning)',
      'gpt-4o-search-preview',
      'gpt-4o-mini-tts',
      'Multi-provider fallback (GLM, Groq, Gemini, edge-tts)',
    ],
    body: "Built for the National AI Hackathon at FAST NUCES Islamabad. Snap a photo of any packaged food label — get a personalized verdict in Roman Urdu, spoken aloud for the 40% of Pakistan's 33M diabetics who can't read.",
    engineeringNote:
      '4-model pipeline (Vision → Reasoning → Search → TTS) with multi-provider fallback. Curated knowledge base: 50+ hidden sugar aliases, 10 allergen categories, WHO daily limits. Searches real Pakistani stores (Naheed, Chase Up, Carrefour, Imtiaz, Al-Fatah, Daraz).',
    ctas: [
      {
        label: 'Source',
        href: 'https://github.com/ammarasad2005/glucoguard-plus',
        variant: 'ghost',
      },
      { label: 'Case study', href: '#', variant: 'ghost' },
    ],
    repoUrl: 'https://github.com/ammarasad2005/glucoguard-plus',
    deepDive: 'glucoguard-pipeline',
    bodyType: 'star',
  },
  {
    id: 'internship-finder',
    title: 'Internship-Finder',
    subtitle: 'An internship discovery platform — currently in active development.',
    pillar: 'ai',
    status: 'building',
    badge: '🛠️ Building Now — Phase 18 production bootstrap',
    stackChips: [
      'Next.js 16',
      'React 19',
      'TypeScript',
      'Supabase',
      'Zod',
      'React Hook Form',
      'Claude Code workflow',
    ],
    body: 'Not just code — a dev workflow. 21+ phase architecture docs, AGENTS.md, FIRST_RUN_POSTMORTEM_TEMPLATE.md, feature-based architecture (features/, lib/, mocks/, scripts/), proper Supabase migrations. Currently in Phase 18: production bootstrap.',
    engineeringNote:
      "158 files · 5,610 LoC · 53 commits · sophisticated dev workflow. Phase 17 implemented a feedback learning loop — there's an ML component here.",
    ctas: [
      {
        label: 'Source',
        href: 'https://github.com/ammarasad2005/Internship-Finder',
        variant: 'ghost',
      },
      {
        label: 'Live dev log',
        href: 'https://github.com/ammarasad2005/Internship-Finder/commits/main',
        variant: 'ghost',
      },
    ],
    repoUrl: 'https://github.com/ammarasad2005/Internship-Finder',
    deepDive: 'internship-finder-workflow',
    bodyType: 'satellite',
  },
  {
    id: 'gcr-resources-fetch',
    title: 'GCR Fetch',
    subtitle:
      'Bulk-download every resource from a Google Classroom course as a single ZIP.',
    pillar: 'web',
    status: 'complete',
    stackChips: [
      'Chrome Extension',
      'JavaScript',
      'Node.js backend',
      'manifest v3',
    ],
    body: 'Exam season pain point: 20–25 minutes of manual clicking. GCR Fetch does it in one click.',
    engineeringNote: '3 stars — my most-adopted open-source tool.',
    ctas: [
      {
        label: 'Source',
        href: 'https://github.com/ammarasad2005/gcr-resources-fetch',
        variant: 'ghost',
      },
      {
        label: 'Install',
        href: 'https://github.com/ammarasad2005/gcr-resources-fetch',
        variant: 'primary',
      },
    ],
    repoUrl: 'https://github.com/ammarasad2005/gcr-resources-fetch',
    bodyType: 'comet',
  },
  {
    id: 'wayfinder',
    title: 'WayFinder',
    subtitle: 'Early exploration: Yango ride-hailing deep-link helper.',
    pillar: 'mobile',
    status: 'early',
    stackChips: ['Next.js', 'TypeScript'],
    body: 'An early experiment in ride-hailing deep links. 5 commits, no README yet — being honest about where this is.',
    engineeringNote:
      'Honest framing: this is early. It exists to show I tinker, not to overstate maturity.',
    ctas: [
      {
        label: 'Source',
        href: 'https://github.com/ammarasad2005/WayFinder',
        variant: 'ghost',
      },
    ],
    repoUrl: 'https://github.com/ammarasad2005/WayFinder',
    bodyType: 'speck',
  },
];

export const projectById = (id: string): Project | undefined =>
  projects.find((p) => p.id === id);

/** Visual scene position per project — gentle arc through 3D space. */
export const projectPositions: Record<string, [number, number, number]> = {
  'exam-table': [-6, 0.5, -4],
  'drama-ghar': [-2, -0.5, -2],
  'hamara-rozgar': [2, 0.8, -1],
  'glucoguard-plus': [6, -0.3, -3],
  'internship-finder': [4, 2.2, -6],
  'gcr-resources-fetch': [-4, -1.4, -8],
  wayfinder: [0, 3.5, -12],
};
