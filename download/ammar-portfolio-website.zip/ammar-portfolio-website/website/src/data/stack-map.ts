// Stack map data for Beat 5 — engineering stack as a star map.
// Source: phase8_storytelling.md Beat 5 + phase5 analysis_cache.json.

import type { Pillar } from './projects';

export interface StackEntry {
  name: string;
  /** Number of the 7 portfolio repos that use this technology. */
  repoCount: number;
  pillar: Pillar;
  /** Extra signal — e.g. Playwright is "only repo with E2E" → pulse it. */
  pulse?: boolean;
}

export const stackMap: StackEntry[] = [
  { name: 'React', repoCount: 5, pillar: 'web' },
  { name: 'Next.js', repoCount: 4, pillar: 'web' },
  { name: 'TypeScript', repoCount: 5, pillar: 'web' },
  { name: 'Tailwind', repoCount: 2, pillar: 'web' },
  { name: 'Supabase', repoCount: 3, pillar: 'web' },
  { name: 'Zod', repoCount: 3, pillar: 'web' },
  { name: 'React Hook Form', repoCount: 3, pillar: 'web' },
  { name: 'Radix/shadcn', repoCount: 2, pillar: 'web' },
  { name: 'Framer Motion', repoCount: 1, pillar: 'web' },
  { name: 'Playwright', repoCount: 1, pillar: 'web', pulse: true },
  { name: 'Mongoose', repoCount: 1, pillar: 'web' },
  { name: 'Python', repoCount: 2, pillar: 'ai' },
  { name: 'OpenAI SDK', repoCount: 1, pillar: 'ai' },
  { name: 'Capacitor', repoCount: 1, pillar: 'mobile' },
];

export const TOTAL_REPOS = 7;

export const engineeringRigorNote =
  'Engineering rigor: 2/7 repos tested (Playwright E2E in Exam-Table, scratch tests in hamara-rozgar). 0/7 with CI. Honest gap. If I shipped any of these today with senior-engineer eyes, I\'d add: GitHub Actions CI, Vitest unit tests, Playwright E2E across the board. Working on it.';
